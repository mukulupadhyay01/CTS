/**********To Top**********/
$(function(){
    $(document).on( 'scroll', function(){
        if ($(window).scrollTop() > 100) {
            $('.scroll-top-wrapper').addClass('show');
        } else {
            $('.scroll-top-wrapper').removeClass('show');
        }
    });
    $('.scroll-top-wrapper').on('click', scrollToTop);
});
function scrollToTop() {
    verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;
    element = $('body');
    offset = element.offset();
    offsetTop = offset.top;
    $('html, body').animate({scrollTop: offsetTop}, 500, 'linear');
}

/**********Fixed nav********/
var nums = $('.mainNav').offset().top;
$(window).scroll(function() {
	if ($(window).scrollTop() > nums) {
		$('.mainNav').addClass('fixednav');
	} else {
		$('.mainNav').removeClass('fixednav');
		nums = $('.mainNav').offset().top;
	}
});

/**********Video Modal********/
$(document).ready(function () {
    var $videoSrc;
    $('.video-btn').click(function () {
      $videoSrc = $(this).data("src");
    });
    console.log($videoSrc);
    $('#VideoModal').on('shown.bs.modal', function (e) {
      $("#videourl").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
    });
    $('#VideoModal').on('hide.bs.modal', function (e) {
      $("#videourl").attr('src', $videoSrc);
    });
});

/**********Timer********/
function makeTimer() 
    {
	//		var endTime = new Date("29 April 2018 9:56:00 GMT+01:00");	
		var endTime = new Date("23 March 2020 9:56:00 GMT+01:00");			
        endTime = (Date.parse(endTime) / 1000);
        var now = new Date();
        now = (Date.parse(now) / 1000);
        var timeLeft = endTime - now;
        var days = Math.floor(timeLeft / 86400); 
        var hours = Math.floor((timeLeft - (days * 86400)) / 3600);
        var minutes = Math.floor((timeLeft - (days * 86400) - (hours * 3600 )) / 60);
        var seconds = Math.floor((timeLeft - (days * 86400) - (hours * 3600) - (minutes * 60)));
        if (hours < "10") { hours = "0" + hours; }
        if (minutes < "10") { minutes = "0" + minutes; }
        if (seconds < "10") { seconds = "0" + seconds; }
        $("#days").html(days + "<span>days</span>");
        $("#hours").html(hours + "<span>hrs</span>");
        $("#minutes").html(minutes + "<span>mins</span>");
        $("#seconds").html(seconds + "<span>secs</span>");
	}
    setInterval(function() { makeTimer(); }, 1000);
    
$('.card-header').click(function(){
    $(this).parent().siblings().children().removeClass('show');
});
