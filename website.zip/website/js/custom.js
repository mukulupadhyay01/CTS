/**********To Top**********/
$(function(){
    new WOW().init();
    $(document).on( 'scroll', function(){
        if ($(window).scrollTop() > 100) {
            $('.scroll-top-wrapper').addClass('show');
        } else {
            $('.scroll-top-wrapper').removeClass('show');
        }
    });
    $('.scroll-top-wrapper').on('click', scrollToTop);
});
function scrollToTop() {
    verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;
    element = $('body');
    offset = element.offset();
    offsetTop = offset.top;
    $('html, body').animate({scrollTop: offsetTop}, 500, 'linear');
}


/**********Fixed nav********/
var nums = $('.main_menu').offset().top;
$(window).scroll(function() {
	if ($(window).scrollTop() > nums) {
		$('.main_menu').addClass('fixednav');
	} else {
		$('.main_menu').removeClass('fixednav');
		nums = $('.main_menu').offset().top;
	}
});


/**********PRELOADER********/
$(window).on("load", function(){
    var d = new Date();
    var n = d.getTime();;
    (function($, window, document, undefined) {
        var s = document.body || document.documentElement,
            s = s.style,
            prefixTransition = "";
        if (s.WebkitTransition === "") prefixTransition = "-webkit-";
        if (s.MozTransition === "") prefixTransition = "-moz-";
        if (s.OTransition === "") prefixTransition = "-o-";
        $.fn.extend({
            onCSSTransitionEnd: function(callback) {
                var $this = $(this).eq(0);
                $this.one("webkitTransitionEnd mozTransitionEnd oTransitionEnd otransitionend transitionend", callback);
                if ((prefixTransition == "" && !("transition" in s)) || $this.css(prefixTransition + "transition-duration") == "0s") {
                    callback();
                } else {
                    var arr_1 = $this.css(prefixTransition + "transition-duration").split(", ");
                    var arr_2 = $this.css(prefixTransition + "transition-delay").split(", ");
                    length = 0;
                    for (var i = 0; i < arr_1.length; i++) {
                        length = parseFloat(arr_1[i]) + parseFloat(arr_2[i]) > length ? parseFloat(arr_1[i]) + parseFloat(arr_2[i]) : length;
                    };
                    var d = new Date();
                    var l = d.getTime();
                    if ((l - n) > length * 1000) {
                        callback();
                    }
                }
                return this;
            }
        });
    })(jQuery, window, document);
    $("#preloader").addClass("loading");
    $("#preloader #loader").onCSSTransitionEnd(function() {
        $("#preloader").addClass("ended");
    });
});


/**********After / Before********/
$(".twentytwenty-container[data-orientation!='vertical']").twentytwenty({default_offset_pct: 0.5});


/**********Language Options********/
$('.drop').click(function(){
    $('.drop-down').toggleClass('open')
});


/**********Youtbe Video Play********/
$("#yt-btn1").click(function () {
    $(this).parent().hide();
    $(this).parent().parent().addClass('hideafter');
    $("#yt1")[0].src += "&autoplay=1";
    setTimeout(function(){ $("#yt1").show(); }, 200);
});
$("#yt-btn2").click(function () {
    $(this).parent().hide();
    $(this).parent().parent().addClass('hideafter');
    $("#yt2")[0].src += "&autoplay=1";
    setTimeout(function(){ $("#yt2").show(); }, 200);
});


/**********Fancybox Modal********/
$(".group1").fancybox({
    openEffect: 'elastic',
    closeEffect: 'elastic',
    fitToView: false,
    maxWidth: "90%"
});